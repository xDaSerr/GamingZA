# config.py
class Config:
    SECRET_KEY = 'clave_secreta'
    MYSQL_HOST = '127.0.0.1'  # o 'localhost'
    MYSQL_USER = 'root'
    MYSQL_PASSWORD = '12345'
    MYSQL_DB = 'gamingza'

